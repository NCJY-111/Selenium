
import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.support.PageFactory;

public class SeleniumWebApp {

    public static void main(String[] args) {
        System.out.println("Hello World");


    }

}